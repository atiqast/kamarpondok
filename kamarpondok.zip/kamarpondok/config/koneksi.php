<?php
//variabel koneksi
$konek = mysqli_connect("localhost","root","","dbkamar");

if(!$konek){
	echo "Koneksi Database Gagal...!!!";
}
?>