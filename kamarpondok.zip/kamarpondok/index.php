<?php include "header.php"; ?>
<div class="jumbotron text-center">
	<h3>Management Kamar Pondok</h3>
	<h2><strong>KAMAR PONDOK</strong></h2>
</div>

<?php include "footer.php"; ?>
